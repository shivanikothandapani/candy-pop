/* Candy Pop — game logic (original functionality preserved 100%) */
(() => {
"use strict";
const N=8,$=id=>document.getElementById(id),sleep=ms=>new Promise(r=>setTimeout(r,ms));
const LV=[];for(let i=0;i<15;i++)LV.push({m:Math.max(14,30-Math.floor(i*1.1)),g:700+i*420,c:i<3?5:6});
const CC=['#ff6b81','#ffa94d','#ffe066','#69db7c','#4dabf7','#cc5de8'];
let S={un:0,st:[],mu:0,sf:0};
try{Object.assign(S,JSON.parse(localStorage.getItem('candypop1')||'{}'))}catch(e){}
const save=()=>{try{localStorage.setItem('candypop1',JSON.stringify(S))}catch(e){}};
let AC;function ac(){if(!AC){try{AC=new(window.AudioContext||window.webkitAudioContext)()}catch(e){}}if(AC&&AC.state==='suspended')AC.resume();return AC}
function tn(f,d=.12,ty='sine',v=.14,dl=0,mus){if(mus?S.mu:S.sf)return;const a=ac();if(!a)return;const o=a.createOscillator(),g=a.createGain(),t=a.currentTime+dl;o.type=ty;o.frequency.value=f;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(a.destination);o.start(t);o.stop(t+d)}
const SEQ=[523,659,784,659,587,698,880,698,523,659,784,1047,988,784,659,587];let mi=0;
let musicTimer=null;
function startMusic(){
  if(musicTimer) return;
  musicTimer=setInterval(()=>{if(AC&&!S.mu&&!document.hidden)tn(SEQ[mi++%16]/2,.3,'triangle',.05,0,1)},300);
}
function stopMusic(){ if(musicTimer){clearInterval(musicTimer);musicTimer=null} }

document.addEventListener('pointerdown',()=>{ac(); startMusic();},{once:true});
document.addEventListener('visibilitychange',()=>{ if(document.hidden) { if(AC&&AC.state==='running') AC.suspend(); } else { if(AC&&AC.state==='suspended') AC.resume(); } });

function sfxBtns(){document.querySelectorAll('[data-a]').forEach(b=>{const k=b.dataset.a;b.textContent=k==='mu'?(S.mu?'🎵✖':'🎵'):(S.sf?'🔊✖':'🔊');b.setAttribute('aria-label', k==='mu' ? (S.mu?'Unmute music':'Mute music') : (S.sf?'Unmute sounds':'Mute sounds'));b.onclick=()=>{S[k]=S[k]?0:1;save();sfxBtns()}})}

// expose for inline onclick handlers
window.sfxBtns = sfxBtns;

// map
function showMap(){
  $('nodes').innerHTML='';
  LV.forEach((l,i)=>{const b=document.createElement('button'),s=S.st[i]||0;
    b.className='nd'+(i>S.un?' lk':'')+(i===S.un?' cur':'');b.style.setProperty('--x',Math.round(Math.sin(i*1.2)*70)+'px');
    b.innerHTML=(i>S.un?'🔒':i+1)+(s?'<i>'+'★'.repeat(s)+'</i>':'');b.setAttribute('aria-label', i>S.un ? `Level ${i+1} locked` : `Level ${i+1} ${s? s+' stars':''}`);
    b.onclick=()=>intro(i);$('nodes').appendChild(b)});
  $('game').classList.remove('on');$('map').classList.add('on');
  setTimeout(()=>{const c=$('nodes').querySelector('.cur')||$('nodes').lastChild;c&&c.scrollIntoView({block:'center',behavior:'smooth'})},50);
}
function modal(h){$('cd').innerHTML=h;$('md').classList.add('on'); sfxBtns(); }
function close_(){$('md').classList.remove('on')}
function intro(i){modal(`<h2>Level ${i+1}</h2><p>Score <b>${LV[i].g}</b> points<br>in <b>${LV[i].m}</b> moves</p><button class="btn g" onclick="start(${i})">Play!</button><button class="btn p" onclick="close_()">Back</button>`)}
window.showMap = showMap;
window.close_ = close_;
window.intro = intro;

// game
let lv=0,g=[],els={},uid=0,score=0,moves=0,busy=true,sel=null,down=null,last=[],run=0;
const L=()=>LV[lv],rnd=()=>Math.floor(Math.random()*L().c),mk=(r,c,t)=>({id:uid++,t:t===undefined?rnd():t,r,c,s:''});
function start(i){lv=i;close_();$('map').classList.remove('on');$('game').classList.add('on');init()}
window.start = start;
function init(){
  run++;Object.values(els).forEach(e=>e.remove());els={};g=[];$('fx').innerHTML='';$('bn').innerHTML='';
  for(let r=0;r<N;r++){g[r]=[];for(let c=0;c<N;c++){let t;do{t=rnd()}while((c>1&&g[r][c-1].t===t&&g[r][c-2].t===t)||(r>1&&g[r-1][c].t===t&&g[r-2][c].t===t));g[r][c]=mk(r,c,t)}}
  score=0;moves=L().m;sel=null;last=[];busy=false;$('lt').textContent='Level '+(lv+1);$('gl').textContent=L().g;
  draw();hud();if(!hasMove())reshuffle();
}
window.init=init;
function hud(){$('sc').textContent=score;$('mv').textContent=moves;const t=L().g*2;$('pg').style.width=Math.min(100,score/t*100)+'%';
  [1,2,3].forEach(n=>{const u=$('s'+n);u.style.left=(L().g*[1,1.5,2][n-1]/t*100-7)+'%';u.classList.toggle('on',score>=L().g*[1,1.5,2][n-1])})}
function draw(){
  const live=new Set();
  for(let r=0;r<N;r++)for(let c=0;c<N;c++){const t=g[r][c];if(!t)continue;live.add(t.id);let e=els[t.id];
    if(!e){e=document.createElement('div');e.innerHTML='<div class="cd"></div>';e.style.left=c*12.5+'%';e.style.top='-14%';$('board').appendChild(e);els[t.id]=e;e.offsetWidth}
    e.className='k '+(t.t<0?'cb':'c'+t.t)+(t.s&&t.s!=='b'?' s'+t.s:'')+(sel&&sel.r===r&&sel.c===c?' sel':'')+(e._p?' pop':'');
    e.style.left=c*12.5+'%';e.style.top=r*12.5+'%'}
  for(const id in els)if(!live.has(+id)){els[id].remove();delete els[id]}
}
function pos(r,c){return `left:${(c+.5)*12.5}%;top:${(r+.5)*12.5}%`}
function fx(r,c,t,big){const n=big?12:5;for(let i=0;i<n;i++){const p=document.createElement('div');p.className='pt';const a=Math.random()*6.28,d=20+Math.random()*(big?60:35);
  p.style.cssText=pos(r,c)+`;background:${CC[t]||'#fff'};--dx:${Math.cos(a)*d}px;--dy:${Math.sin(a)*d}px`;$('fx').appendChild(p);setTimeout(()=>p.remove(),650)}}
function popup(r,c,txt){const p=document.createElement('div');p.className='pu';p.textContent=txt;p.style.cssText=pos(r,c);$('fx').appendChild(p);setTimeout(()=>p.remove(),950)}
function banner(t){const b=document.createElement('div');b.className='bnr';b.textContent=t;$('bn').appendChild(b);setTimeout(()=>b.remove(),1100)}
function pk(run_){return run_.find(x=>last.includes(x.id))||run_[run_.length>>1]}
function find(){
  const m=new Set(),H=[],V=[];
  for(const hz of[1,0])for(let a=0;a<N;a++){const at=i=>hz?g[a][i]:g[i][a];let b=0;
    while(b<N){const t=at(b);if(!t||t.t<0){b++;continue}let e=b;while(e+1<N&&at(e+1)&&at(e+1).t===t.t)e++;
      if(e-b>=2){const rn=[];for(let k=b;k<=e;k++){rn.push(at(k));m.add(at(k))}(hz?H:V).push(rn)}b=e+1}}
  const cr=new Map();
  for(const h of H)for(const v of V){const x=h.find(t=>v.includes(t));if(x)cr.set(x,'w')}
  for(const h of H)if(h.length>=4){const t=pk(h);if(!cr.has(t)||h.length>=5)cr.set(t,h.length>=5?'b':'v')}
  for(const v of V)if(v.length>=4){const t=pk(v);if(!cr.has(t)||v.length>=5)cr.set(t,v.length>=5?'b':'h')}
  return{m,cr}
}
function expand(m){const q=[...m],add=x=>{if(x&&!m.has(x)){m.add(x);q.push(x)}};
  while(q.length){const t=q.pop();
    if(t.s==='h')for(let i=0;i<N;i++)add(g[t.r][i]);
    else if(t.s==='v')for(let i=0;i<N;i++)add(g[i][t.c]);
    else if(t.s==='w')for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++){const rr=t.r+a,cc=t.c+b;if(rr>=0&&rr<N&&cc>=0&&cc<N)add(g[rr][cc])}}}
function combo(A,B){
  const all=g.flat(),F=new Set([A,B]),st=x=>x.s==='h'||x.s==='v',col=x=>all.filter(t=>t.t===x.t);
  if(A.s==='b'&&B.s==='b')return new Set(all);
  if(A.s==='b'||B.s==='b'){const b=A.s==='b'?A:B,o=b===A?B:A;
    col(o).forEach(t=>{if(o.s&&o.s!=='b'&&!t.s)t.s=o.s==='w'?'w':(Math.random()<.5?'h':'v');F.add(t)});return F}
  if(st(A)&&st(B)){for(let i=0;i<N;i++){F.add(g[B.r][i]);F.add(g[i][B.c])}return F}
  if(A.s==='w'&&B.s==='w'){all.forEach(t=>{if(Math.abs(t.r-B.r)<=2&&Math.abs(t.c-B.c)<=2)F.add(t)});return F}
  if((A.s==='w'&&st(B))||(B.s==='w'&&st(A))){all.forEach(t=>{if(Math.abs(t.r-B.r)<=1||Math.abs(t.c-B.c)<=1)F.add(t)});return F}
  return null}
async function resolve(force){
  let cb=0;const my=run;
  while(my===run){
    const f=find(),m=f.m;if(force){force.forEach(t=>m.add(t));force=null}
    if(!m.size)break;cb++;expand(m);
    let sp=0;m.forEach(t=>{if(t.s)sp++});
    f.cr.forEach((k,t)=>{if(!t.s&&t.t>=0&&m.has(t)){t.s=k;if(k==='b')t.t=-1;m.delete(t);fx(t.r,t.c,t.t,1)}});
    const pts=m.size*20*cb+sp*60;score+=pts;hud();last=[];
    if(sp){tn(300,.3,'sawtooth',.1);tn(600,.25,'square',.06,.05);tn(900,.2,'square',.05,.1)}
    tn(480+Math.min(cb,8)*70,.16,'triangle',.16);
    if(cb>1)banner(['','','Sweet!','Tasty!','Delicious!','Divine!'][Math.min(cb,5)]);
    let ar=0,ac_=0;m.forEach(t=>{const e=els[t.id];if(e){e._p=1;e.classList.add('pop')}fx(t.r,t.c,t.t,t.s);g[t.r][t.c]=null;ar+=t.r;ac_+=t.c});
    popup(ar/m.size,ac_/m.size,'+'+pts);
    await sleep(300);
    for(let c=0;c<N;c++){const col=[];for(let r=N-1;r>=0;r--)if(g[r][c])col.push(g[r][c]);
      for(let r=N-1;r>=0;r--){const t=col[N-1-r]||mk(r,c);t.r=r;t.c=c;g[r][c]=t}}
    draw();await sleep(420)}
}
function swap(a,b){const ta=g[a.r][a.c],tb=g[b.r][b.c];g[a.r][a.c]=tb;g[b.r][b.c]=ta;tb.r=a.r;tb.c=a.c;ta.r=b.r;ta.c=b.c}
function hasMove(){
  if(g.flat().some(t=>t.s==='b'))return true;
  for(let r=0;r<N;r++)for(let c=0;c<N;c++)for(const[dr,dc]of[[0,1],[1,0]]){const r2=r+dr,c2=c+dc;if(r2>=N||c2>=N)continue;
    swap({r,c},{r:r2,c:c2});const ok=find().m.size>0;swap({r,c},{r:r2,c:c2});if(ok)return true}
  return false}
function reshuffle(){let n=0;do{const a=g.flat().filter(t=>t.t>=0),v=a.map(t=>t.t).sort(()=>Math.random()-.5);a.forEach((t,i)=>t.t=v[i]);
  a.forEach(t=>{g[t.r][t.c]=t});n++}while((find().m.size||!hasMove())&&n<50);draw();banner('Shuffle!')}
async function tryMove(a,b){
  if(busy||Math.abs(a.r-b.r)+Math.abs(a.c-b.c)!==1)return;
  busy=true;sel=null;const my=run;
  swap(a,b);const A=g[a.r][a.c],B=g[b.r][b.c];last=[A.id,B.id];draw();tn(400,.08,'sine',.1);await sleep(260);
  const F=(A.s||B.s)?combo(A,B):null;
  if(!F&&!find().m.size){tn(200,.15,'square',.08);swap(a,b);draw();await sleep(260);busy=false;return}
  moves--;hud();await resolve(F);if(my!==run)return;
  if(score>=L().g){win();return}
  if(moves<=0){lose();return}
  if(!hasMove()){reshuffle();await sleep(400);await resolve();}
  busy=false}
function win(){
  busy=true;const r=score/L().g,s=r>=2?3:r>=1.5?2:1;
  S.st[lv]=Math.max(S.st[lv]||0,s);if(lv>=S.un&&lv<LV.length-1)S.un=lv+1;save();
  [523,659,784,1047].forEach((f,i)=>tn(f,.3,'triangle',.18,i*.14));
  setTimeout(()=>{modal(`<h2>Level Complete!</h2><div class="stars">${[1,2,3].map(n=>`<span class="${n<=s?'y':''}" style="animation-delay:${n*.25}s">★</span>`).join('')}</div><p>Score <b>${score}</b></p>${lv<LV.length-1?`<button class="btn g" onclick="start(${lv+1})">Next Level</button>`:'<p>🏆 You beat every level!</p>'}<button class="btn" onclick="start(${lv})">Replay</button><button class="btn p" onclick="close_();showMap()">Map</button>`);confetti()},500)}
function lose(){busy=true;tn(300,.3,'sawtooth',.1);tn(200,.4,'sawtooth',.1,.25);
  setTimeout(()=>modal(`<h2>Out of Moves!</h2><p>Score ${score} / ${L().g}</p><button class="btn g" onclick="start(${lv})">Try Again</button><button class="btn p" onclick="close_();showMap()">Map</button>`),400)}
function pause(){modal(`<h2>Paused</h2><button class="btn g" onclick="close_()">Resume</button><button class="btn" onclick="start(lv)">Restart</button><div class="tb" style="justify-content:center"><button class="btn s p" data-a="mu" aria-label="Toggle music"></button><button class="btn s p" data-a="sf" aria-label="Toggle sound"></button></div><button class="btn p" onclick="close_();showMap()">Map</button>`);}
window.pause=pause;
window.win=win;
window.lose=lose;

function confetti(){for(let i=0;i<60;i++){const c=document.createElement('div');c.className='cf';c.style.cssText=`left:${Math.random()*100}vw;background:${CC[i%6]};animation-delay:${Math.random()*.8}s;animation-duration:${2+Math.random()*1.5}s`;document.body.appendChild(c);setTimeout(()=>c.remove(),4500)}}
// input
const cell=e=>{const b=$('board').getBoundingClientRect();return{r:Math.min(N-1,Math.max(0,Math.floor((e.clientY-b.top)/b.height*N))),c:Math.min(N-1,Math.max(0,Math.floor((e.clientX-b.left)/b.width*N)))}};
const bw=document.querySelector('.bw');
if(bw){
  bw.addEventListener('pointerdown',e=>{if(busy||$('md').classList.contains('on'))return;down={x:e.clientX,y:e.clientY,p:cell(e)};
    if(!sel){sel=down.p;draw()}else if(Math.abs(sel.r-down.p.r)+Math.abs(sel.c-down.p.c)===1){const a=sel;down=null;tryMove(a,cell(e))}else if(sel.r===down.p.r&&sel.c===down.p.c){}else{sel=down.p;draw()}});
  bw.addEventListener('pointermove',e=>{if(!down||busy)return;const dx=e.clientX-down.x,dy=e.clientY-down.y;
    if(Math.max(Math.abs(dx),Math.abs(dy))>18){const p=down.p,q=Math.abs(dx)>Math.abs(dy)?{r:p.r,c:p.c+(dx>0?1:-1)}:{r:p.r+(dy>0?1:-1),c:p.c};down=null;
      if(q.r>=0&&q.r<N&&q.c>=0&&q.c<N)tryMove(p,q)}});
  bw.addEventListener('pointerup',()=>{down=null});
  bw.addEventListener('pointercancel',()=>{down=null});
}
document.addEventListener('touchmove',e=>{if($('game').classList.contains('on'))e.preventDefault()},{passive:false});

// bubbles decoration
for(let i=0;i<12;i++){const b=document.createElement('div');b.className='bub';const s=20+Math.random()*50;b.style.cssText=`width:${s}px;height:${s}px;left:${Math.random()*100}vw;animation-duration:${10+Math.random()*14}s;animation-delay:${-Math.random()*20}s`;document.body.appendChild(b)}

// keyboard support (desktop accessibility)
document.addEventListener('keydown',e=>{
  if(e.key==='Escape' && $('md').classList.contains('on')) close_();
  if(e.key==='Escape' && !$('md').classList.contains('on') && $('game').classList.contains('on')) pause();
});

// loader hide
window.addEventListener('load',()=>{
  setTimeout(()=>{
    const loader=document.getElementById('loader');
    if(loader){loader.classList.add('out'); setTimeout(()=>loader.remove(),600)}
  },400);
});

sfxBtns();showMap();

// Expose for testing
window._CandyPop = { LV, S, start, showMap };

})();
