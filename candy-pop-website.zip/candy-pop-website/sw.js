/* Candy Pop Service Worker — free offline caching for HTTPS performance */
const CACHE = 'candy-pop-v2';
const ASSETS = [
  './',
  './index.html',
  './css/style.css',
  './js/game.js',
  './manifest.json',
  './assets/favicon.svg'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(ASSETS)).then(()=> self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=> self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  // Only cache GET, same-origin
  if (req.method !== 'GET' || !req.url.startsWith(self.location.origin)) return;
  e.respondWith(
    caches.match(req).then(cached => {
      const fetchPromise = fetch(req).then(networkRes => {
        // update cache
        if (networkRes.ok) {
          const clone = networkRes.clone();
          caches.open(CACHE).then(c=> c.put(req, clone));
        }
        return networkRes;
      }).catch(()=> cached);
      return cached || fetchPromise;
    })
  );
});
